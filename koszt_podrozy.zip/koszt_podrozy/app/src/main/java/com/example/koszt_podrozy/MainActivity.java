package com.example.koszt_podrozy;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private EditText etDistance;
    private EditText etConsumption;
    private EditText etPassengers;
    private RadioGroup rgFuelType;
    private Button btnMinus;
    private Button btnPlus;
    private Button btnCalculate;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etDistance = findViewById(R.id.etDistance);
        etConsumption = findViewById(R.id.etConsumption);
        etPassengers = findViewById(R.id.etPassengers);
        rgFuelType = findViewById(R.id.rgFuelType);
        btnMinus = findViewById(R.id.btnMinus);
        btnPlus = findViewById(R.id.btnPlus);
        btnCalculate = findViewById(R.id.btnCalculate);
        tvResult = findViewById(R.id.tvResult);

        btnMinus.setOnClickListener(v -> changePassengers(-1));
        btnPlus.setOnClickListener(v -> changePassengers(1));
        btnCalculate.setOnClickListener(v -> calculateCost());
    }

    private void changePassengers(int delta) {
        int current = 1;
        try {
            String text = etPassengers.getText().toString().trim();
            if (!text.isEmpty()) {
                current = Integer.parseInt(text);
            }
        } catch (NumberFormatException ignored) {
        }

        int updated = Math.max(1, current + delta);
        etPassengers.setText(String.valueOf(updated));
    }

    private void calculateCost() {
        String distText = etDistance.getText().toString().trim();
        String consText = etConsumption.getText().toString().trim();
        String passText = etPassengers.getText().toString().trim();

        if (distText.isEmpty() || consText.isEmpty() || passText.isEmpty()) {
            showError();
            return;
        }

        try {
            double distance = Double.parseDouble(distText);
            double consumption = Double.parseDouble(consText);
            int passengers = Integer.parseInt(passText);

            if (distance <= 0 || consumption <= 0 || passengers < 1) {
                showError();
                return;
            }

            double fuelPrice;
            int selectedId = rgFuelType.getCheckedRadioButtonId();
            if (selectedId == R.id.rbDiesel) {
                fuelPrice = 6.70;
            } else if (selectedId == R.id.rbLpg) {
                fuelPrice = 3.10;
            } else {
                fuelPrice = 6.50;
            }

            double totalCost = (distance * consumption / 100.0) * fuelPrice;
            double costPerPerson = totalCost / passengers;

            tvResult.setTextColor(Color.GREEN);
            tvResult.setText(String.format(
                    new Locale("pl", "PL"),
                    "Całkowity koszt: %.2f zł | Koszt na osobę: %.2f zł",
                    totalCost,
                    costPerPerson
            ));
        } catch (NumberFormatException e) {
            showError();
        }
    }

    private void showError() {
        tvResult.setTextColor(Color.RED);
        tvResult.setText("Niepoprawne dane wejściowe!");
    }
}